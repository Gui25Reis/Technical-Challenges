//
//  PaymentMethodTableViewCell.swift
//  DoorDashDebuggingUIKit
//
//  Created by Mike Zaslavskiy on 8/12/24.
//

import Foundation
import UIKit

class PaymentMethodTableViewCell: UITableViewCell {
    static let id = "PaymentMethodTableViewCell"
    private let titleLabel = UILabel()
    private let iconLabel = UILabel()
    private let selectedCheckMarkLabel = UILabel()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setUpContent()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setUpContent() {
        let stackView = UIStackView(arrangedSubviews: [iconLabel, titleLabel, selectedCheckMarkLabel])
        stackView.axis = .horizontal
        stackView.spacing = 8.0
        contentView.addSubview(stackView)
        stackView.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            stackView.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 16),
            stackView.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -16),
            stackView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16),
            stackView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16),
        ])
        
        titleLabel.textAlignment = .left
        selectedCheckMarkLabel.text = "✔️"
    }
    
    func configure(with paymentMethod: PaymentMethod, isSelected: Bool) {
        titleLabel.text = paymentMethod.name
        selectedCheckMarkLabel.isHidden = !isSelected
        iconLabel.text = iconForPaymentType(paymentMethod.type)
    }
    
    private func iconForPaymentType(_ type: PaymentMethodType) -> String {
        switch type {
        case .applePay:
            return "🍎"
        case .card:
            return "💳"
        case .venmo:
            return "💸"
        }
    }
}
