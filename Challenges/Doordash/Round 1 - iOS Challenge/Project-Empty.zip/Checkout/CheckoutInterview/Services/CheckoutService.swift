//
//  CheckoutService.swift
//  Copyright © 2026 DoorDash, Inc. All rights reserved.
//
// ## Confidentiality Notice
// This interview exercise and all associated materials are confidential
// and proprietary to DoorDash, Inc. By accessing these materials, you
// agree not to share, publish, or distribute any part of this exercise
// or your solution.
//
// Violation of this agreement may result in disqualification from
// consideration for employment at DoorDash.
//

import Foundation
import Combine

class CheckoutService {
    private let session = FakeNetworkSession()
    
    func fetchOrder() {
        session.getOrder { data in
            print(String(data: data, encoding: .utf8)!)
        }
    }
    
    func submitOrder(orderId: String) {
        session.submitOrder(orderId: orderId) { data in
            print(String(data: data, encoding: .utf8)!)
        }
    }
}
